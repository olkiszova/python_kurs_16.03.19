class Foo:
    pass


def hello():
    return "Hello World"


def print():
    return 1

