# import b

from c.d import funkcja_z_d
from b import print as b_print, hello, Foo
import random
import sys
print(sys.path)

print(hello())
bar = Foo()
print(bar)
b_print()