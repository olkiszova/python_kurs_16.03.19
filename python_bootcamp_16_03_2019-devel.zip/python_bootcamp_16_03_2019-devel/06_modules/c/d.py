

def funkcja_z_d():
    pass