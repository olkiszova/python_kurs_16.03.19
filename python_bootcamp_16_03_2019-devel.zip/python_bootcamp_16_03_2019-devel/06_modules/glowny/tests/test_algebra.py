from mathematica.algebra.matrices import add_matrices, add_matrices_v1, add_matrices_v2, sub_matrices


def test_add_matrices():
    a = [
        [1, 2, 3],
        [4, 5, 6]
    ]
    b = [
        [1, 1, 1],
        [1, 1, 1]
    ]

    result = [
        [2, 3, 4],
        [5, 6, 7]
    ]
    assert add_matrices(a, b) == result


def test_add_matrices_v1():
    a = [
        [1, 2, 3],
        [4, 5, 6]
    ]
    b = [
        [1, 1, 1],
        [1, 1, 1]
    ]

    result = [
        [2, 3, 4],
        [5, 6, 7]
    ]
    assert add_matrices_v1(a, b) == result


def test_add_matrices_v2():
    a = [
        [1, 2, 3],
        [4, 5, 6]
    ]
    b = [
        [1, 1, 1],
        [1, 1, 1]
    ]

    result = [
        [2, 3, 4],
        [5, 6, 7]
    ]
    assert add_matrices_v2(a, b) == result


def test_sub_matrices():
    a = [
        [1, 2, 3],
        [4, 5, 6]
    ]
    b = [
        [1, 1, 1],
        [1, 1, 1]
    ]

    result = [
        [0, 1, 2],
        [3, 4, 5]
    ]
    assert sub_matrices(a, b) == result
