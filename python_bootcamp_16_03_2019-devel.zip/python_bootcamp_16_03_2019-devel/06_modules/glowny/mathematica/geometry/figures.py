def square_area(a):
    return a * a

def triangle_area(a, h):
    return 0.5 * a * h
