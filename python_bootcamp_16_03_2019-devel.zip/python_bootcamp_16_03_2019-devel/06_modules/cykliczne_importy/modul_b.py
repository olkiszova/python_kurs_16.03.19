import modul_a

def function2():
    print("Jestem funkcją 2")
