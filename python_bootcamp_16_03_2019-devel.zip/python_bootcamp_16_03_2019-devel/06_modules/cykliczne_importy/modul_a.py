
def function1():
    print("Jestem funkcją 1")


if __name__ == "__main__":
    function1()