import sys

try:
    nazwa_pliku = sys.argv[1]
    with open(nazwa_pliku) as f:
        for index, linia in enumerate(f, start=1):
            print(f"{index}: {linia}", end="")
except IndexError:
    print("Nie podałeś nazwy pliku")

