#
# try:
#     f = open("pierwszy.txt", 'a', encoding="cp1250")
#     f.write("Trzecia linia\n")
# finally:
#     f.close()
#
# with open("pierwszy.txt", 'a', encoding="cp1250") as f:
#     f.write("Trzecia linia\n")
#
#
# print(f)
# f.write("Coś tam")

#
# with open("pierwszy.txt",) as f:
#     for l in f:
#         print(l)
#
# for i, l in enumerate(["a", "b", "c"]):
#     print(i, l)

def print_a():
    print("A")

def print_b():
    print("B")

moje_funkcje = {
    "a": print_a,
    "b": print_b
}

moje_funkcje['b']()
