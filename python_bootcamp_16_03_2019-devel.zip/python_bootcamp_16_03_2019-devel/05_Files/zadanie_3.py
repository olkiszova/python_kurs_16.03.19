import sys

input_file = sys.argv[1]  # "emails.txt"
output_file = sys.argv[2]  # "cleaned_emails.txt"

cleaned = set()
with open(input_file) as input_file:
    for line in input_file:
        if line.count("@") == 1:
            cleaned.add(line.strip().lower() + "\n")

with open(output_file, "w") as output_file:
    for email in cleaned:
        output_file.write(email)
    # output_file.writelines(cleaned)
