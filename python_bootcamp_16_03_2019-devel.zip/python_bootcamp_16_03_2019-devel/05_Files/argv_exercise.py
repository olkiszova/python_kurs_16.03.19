"""

example:

python argv_exercise.py dodaj 1 2
3

python argv_exercise.py mnoz 1 2
2

python argv_exercise.py odejmij 1 2
-1

"""

import sys
print(sys.argv)
lista = sys.argv[1:]

# lista = ["dodaj", "1", "2"]
if len(lista) != 3:
    raise ValueError("Za mało lub za dużo argumentów")

dzialanie = lista[0]
a = int(lista[1])
b = int(lista[2])

if dzialanie == "dodaj":
    wynik = a + b
elif dzialanie == "odejmij":
    wynik = a - b
elif dzialanie == "mnoz":
    wynik = a * b
print(wynik)