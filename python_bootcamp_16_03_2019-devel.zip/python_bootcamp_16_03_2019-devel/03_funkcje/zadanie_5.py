def silnia(a):
    if a == 0:
        return 1
    return a*silnia(a-1)

def test_silnia():
    assert silnia(0) == 1
    assert silnia(3) == 6
    assert silnia(5) == 5*4*6
