# def power(a, b=2):
#     return a**b
#
# print(power(2, 4))
# print(power(2))
#
# def dzialanie(a, b=2, c=3):
#     return a + b * c
#
# print(dzialanie(a=2, c=4, b=3))
#

def dodaj_jeden(a):
    return a + 1

print(dodaj_jeden(10))

def say_hello(name):
    return f"Hello {name}"

def be_awesome(name):
    return f"Yo {name}! You are awesome!"

def greetings(g_func, name):
    return g_func(name)

print(greetings(be_awesome, "Rafał"))

b = "B na głownym poziomie"

def parent():
    a = 1
    print("Print z funkcji parent")
    print(b)

    def first_child():
        print("Printuję z first_child")
        print("Printuję a z funkcji parent", a)

    def second_child():
        c = 1
        print("Printuję z second_child")

    print(locals())
    print(globals())

    first_child()
    second_child()

print("-"*40)
print(locals())
print(globals())
print("-"*40)
parent()
