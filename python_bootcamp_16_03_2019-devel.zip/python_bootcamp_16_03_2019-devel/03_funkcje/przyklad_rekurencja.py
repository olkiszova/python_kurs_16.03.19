
def odlicz(a):
    print(a)
    if a == 1:
        print(0)
        return 0
    else:
        return odlicz(a-1)

odlicz(10)


def rekuprint(lista):
    if len(lista) == 1:
        print(lista[0])
    else:
        print(lista[0])
        rekuprint(lista[1:])

lista = range(1000)

rekuprint(lista)