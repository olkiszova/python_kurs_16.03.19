def formatuj(*args, **kwargs):
    zlaczone = "\n".join(args)

    for k in kwargs:
        zlaczone = zlaczone.replace(f"${k}", str(kwargs[k]))

    return zlaczone

def test_formatuj():
    x = formatuj(
        'koszt $cena PLN',
        'kwota $brutto brutto',
        cena=10,
        brutto=12.3
    )
    assert x == "koszt 10 PLN\nkwota 12.3 brutto"


def test_formatuj_2():
    x = formatuj(
        'ala $kot',
        'kasia $pies, $adres',
        kot="mruczek",
        pies="azor",
        adres="Jasna 14/16"
    )
    assert x == "ala mruczek\nkasia azor, Jasna 14/16"
