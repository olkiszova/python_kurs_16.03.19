def przytnij(data, start, stop):
    result = []

    for element in data:
        if stop(element):
            result.append(element)
            break
        if start(element):
            result.append(element)
    return result

def test_przytnij():
    przytnij_result = przytnij(
        data=[1, 2, 3, 4, 5, 6, 7, 8],
        start=lambda x: x > 3,
        stop=lambda x: x == 6

    )

    assert przytnij_result == [4,5,6]
