class Employee:
    def __init__(self, first_name, last_name, rate_per_hour=100):
        self.first_name = first_name
        self.last_name = last_name
        self.rate_per_hour = rate_per_hour
        self._worked_hours = 0

    def register_time(self, hours):
        self._worked_hours = hours

    def pay_salary(self):
        if self._worked_hours > 8:
            to_pay = 8 * self.rate_per_hour + (self._worked_hours - 8) * 2 * self.rate_per_hour
        else:
            to_pay = self._worked_hours * self.rate_per_hour
        self._worked_hours = 0
        return to_pay


def test_employee_initialization():
    employee = Employee('Jan', 'Nowak', 100.0)
    assert employee.first_name == "Jan"
    assert employee.last_name == "Nowak"
    assert employee.rate_per_hour == 100.0


def test_employee_register_time():
    employee = Employee('Jan', 'Nowak', 100.0)
    assert employee._worked_hours == 0
    # employee.worked_hours = 40
    employee.register_time(5)
    assert employee._worked_hours == 5


def test_employee_pay_salary():
    employee = Employee('Jan', 'Nowak', 100.0)
    assert employee.pay_salary() == 0
    employee.register_time(6)
    assert employee.pay_salary() == 6*100
    assert employee.pay_salary() == 0
    employee.register_time(10)
    assert employee.pay_salary() == 1200



