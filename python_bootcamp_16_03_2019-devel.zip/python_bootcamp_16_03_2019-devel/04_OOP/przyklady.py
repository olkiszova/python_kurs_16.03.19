

class Pies:
    # atrybuty klasowe
    liczba_nog = 4
    gatunek = "Canis Canis"

    def __init__(self, imie, rasa, wiek):
        # atrybuty instancji
        self.imie = imie
        self.rasa = rasa
        self.wiek = wiek
        self.usposobienie = "przyjacielski"

    # metoda instancji
    @property
    def ludzki_wiek(self):
        return self.wiek * 7

    # utwórz metodę opisz_sie


azor = Pies("Azor", "kundel", 10) # instancja klasy Pies
reksio = Pies("Rex", "owczarek niemiecki", 4)

print(reksio.usposobienie)
reksio.usposobienie = "agresywny"
print(reksio.usposobienie)
print(azor.usposobienie)

print(azor.ludzki_wiek)
print(reksio.ludzki_wiek)

# print(azor == reksio)
#
# azor.imie = "Azor"
# azor.rasa = "kundel"
# reksio.imie = "Rex"
# reksio.rasa = "Owczarek"
#
# azor.wiek = 10
# print(azor.ludzki_wiek())
# print(reksio.ludzki_wiek())
# print(azor.liczba_nog)
# print(reksio.liczba_nog)
# print(azor.gatunek)
#
#
#
# produkt1 = Produkt(1, "woda", 10.99)
# produkt2 = Produkt(1, "woda", "brak")
#
#
#

class Foo:

    def __init__(self):
        self.__bar = 10

    def get_bar(self):
        return self.__bar

    # def __str__(self):
    #     return "Jestem instancją klasy Foo"

f = Foo()
print(f)
print(f.get_bar())
print(f._Foo__bar)

print(f.__init__())

#
# car1 = ElectricCar(100)
# car2 = ElectricCar(120)
# car3
