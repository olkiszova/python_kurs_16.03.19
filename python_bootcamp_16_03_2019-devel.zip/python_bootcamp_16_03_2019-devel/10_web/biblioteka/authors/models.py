from django.db import models

# Create your models here.

class Author(models.Model):
    name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)
    biogram = models.TextField(null=True, blank=True)
    age = models.IntegerField(null=True, blank=True)
    email = models.EmailField()
    image = models.ImageField(upload_to="authors/%Y/%m/%d")

    def __str__(self):
        return f"{self.name} {self.last_name}"