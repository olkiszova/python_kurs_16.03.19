tinyMCE.addI18n("en.grappelli_contextmenu",{
grappelli_contextmenu_insertpbefore_desc:"Insert Paragraph BEFORE current element",
grappelli_contextmenu_insertpafter_desc:"Insert Paragraph AFTER current element",
grappelli_contextmenu_insertpbeforeroot_desc:"Insert Paragraph BEFORE current ROOT-LEVEL element",
grappelli_contextmenu_insertpafterroot_desc:"Insert Paragraph AFTER current ROOT-LEVEL element",
grappelli_contextmenu_delete_desc:"Delete current element",
grappelli_contextmenu_deleteroot_desc:"Delete current ROOT-LEVEL element",
grappelli_contextmenu_moveup_desc:"MOVE UP current ELEMENT",
grappelli_contextmenu_moveuproot_desc:"MOVE UP current ROOT-LEVEL element",

P_grappelli_contextmenu_insertpbefore_desc:"Insert Paragraph BEFORE current element",
P_grappelli_contextmenu_insertpafter_desc:"Insert Paragraph AFTER current element",
P_grappelli_contextmenu_insertpbeforeroot_desc:"Insert Paragraph BEFORE current ROOT-LEVEL element",
P_grappelli_contextmenu_insertpafterroot_desc:"Insert Paragraph AFTER current ROOT-LEVEL element",
P_grappelli_contextmenu_delete_desc:"Delete current element",
P_grappelli_contextmenu_deleteroot_desc:"Delete current ROOT-LEVEL element",
P_grappelli_contextmenu_moveup_desc:"MOVE UP current ELEMENT",
P_grappelli_contextmenu_moveuproot_desc:"MOVE UP current ROOT-LEVEL element",

});