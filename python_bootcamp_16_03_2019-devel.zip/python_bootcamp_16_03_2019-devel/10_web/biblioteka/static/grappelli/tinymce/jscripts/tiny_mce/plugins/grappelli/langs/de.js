tinyMCE.addI18n("de.grappelli",{
grappelli_adv_desc:"Erweitertes Menü anzeigen/verbergen",
grappelli_documentstructure_desc:"Dokumentenstruktur anzeigen/verbergen",
});
