from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.
from books.models import Book

ksiazki = [{'title': "W pustyni i puszczy", 'id': 1}, {'title': "Rok 1984", 'id': 2}]


def hello_world(request, name=""):
    if name:
        text = f"Hello {name}"
    else:
        text = "Hello World"
    return HttpResponse(text)


# def lista_ksiazek(request):
#
#     output = ""
#     for k in ksiazki:
#         output += k['title'] + "<br>"
#
#     return HttpResponse(output)


def books_list(request):
    ksiazki = Book.objects.all()
    return render(
        request=request,
        template_name="index.html",
        context={'ksiazki': ksiazki}
    )


def book_details(request, id):
    ksiazka = Book.objects.get(pk=id)
    return render(
        request=request,
        template_name="details.html",
        context={'ksiazka': ksiazka}
    )
