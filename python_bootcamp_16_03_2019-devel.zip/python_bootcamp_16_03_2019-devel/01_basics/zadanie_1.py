import math

print(math.pi)

# ex 1
print(10*5/2)

# ex 2
print(math.pi*(7**2))

# ex 3
print(((3+9)*6.5)/2)

# ex 4
# 4/3 * pi * r^3
print((4/3) * math.pi * (7/8)**3)


