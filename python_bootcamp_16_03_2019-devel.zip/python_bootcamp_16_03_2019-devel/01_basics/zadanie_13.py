# i = 0
# suma_temperatur = 0
#
# while i != 7:
#     suma_temperatur += float(input("Podaj temperaturę: "))
#     i = i + 1  # i += 1
#     print(i, suma_temperatur)
#
# print("Średnia: ", suma_temperatur, i, suma_temperatur / i)

# i = 0
# suma_temperatur = 0
#
# while True:
#     komenda = input("Podaj temperaturę lub wpisz [k] by zakończyć: ")
#
#     if komenda == 'k':
#         break
#
#     suma_temperatur += float(komenda)
#     i = i + 1  # i += 1
#     print(i, suma_temperatur)
#
# print("Średnia: ", suma_temperatur, i, suma_temperatur / i)

n=10

while n > 0:
    n -= 1
    print("foo", n)

print("To jest poza pętlą")