wartosc_min = None
wartosc_max = None

while True:
    komenda = input("Podaj liczbe: ")
    liczba = None

    if komenda == "k":
        break

    try:
        liczba = int(komenda)
    except:
        print("Powinieneś wpisać liczbe lub [k] by zakonczyc")

    if liczba is not None: # True 232 "123"
        if wartosc_min is None or liczba < wartosc_min:
            wartosc_min = liczba

        if wartosc_max is None or liczba > wartosc_max:
            wartosc_max = liczba

print(f"Max: {wartosc_max}")
print(f"Min: {wartosc_min}")

