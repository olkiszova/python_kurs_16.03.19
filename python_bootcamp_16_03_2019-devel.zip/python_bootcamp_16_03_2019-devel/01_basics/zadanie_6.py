liczba = input("Podaj liczbę: ")
liczba = int(liczba)

#liczba = liczba + 10
#liczba += 10

print(f"""
Wieksza od 10: {liczba > 10}
Mniejsza równa 15: {liczba <= 15}
Podzielna przez 2: {liczba % 2 == 0}
""")