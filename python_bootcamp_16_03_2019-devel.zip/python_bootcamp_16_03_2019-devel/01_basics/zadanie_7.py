liczba = int(input("Podaj liczbę: "))

wynik = (liczba % 2 == 0 and liczba % 3 == 0 and liczba > 10) or liczba == 7
print(
    "Czy liczba jest podzielna przez 2, podzielna przez 3 i wieksza od 10 lub jest to liczba 7 ",
    wynik
      )

