a = input("Miasto A: ")
b = input("Miasto B: ")
dystans = input(f"Dystans {a}-{b}: ")
cena_paliwa = input("Cena paliwa: ")
spalanie = input("Spalanie na 100 km: ")

koszt = (int(dystans) / 100) * float(spalanie) * float(cena_paliwa)
# koszt = round(koszt, 2)
print(f"Koszt przejazdu {a}-{b} to {koszt:.2f} PLN")