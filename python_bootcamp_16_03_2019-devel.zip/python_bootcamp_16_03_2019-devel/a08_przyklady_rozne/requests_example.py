import urllib.request
import json

import requests

# with urllib.request.urlopen("http://api.nbp.pl/api/exchangerates/tables/A?format=json") as f:
#     # print(f.read())
#     data = json.loads(f.read())
#     rates = data[0]['rates']
#     for rate in rates:
#         print(rate)

r = requests.get('http://api.nbp.pl/api/exchangerates/tables/A?format=json')
data = r.json()
rates = data[0]['rates']

print("Oferujemy waluty: ")
for rate in rates:
    print(f" - {rate['code']} - {rate['mid']} ({rate['currency']})")

code = input("Jaką walutę chcesz kupić? ")
amount = float(input(f"Za ile PLN chcesz kupić {code}? "))

rate = None
for r in rates:
    if r['code'] == code:
        rate = float(r['mid'])

result = amount / rate
print(f"Za {amount} PLN kupisz {result:.2f} {code}" )

