import json

try:
    with open("pracownicy.json") as file:
        employes = json.load(file)
except FileNotFoundError:
    employes = []

action = input("Co chcesz zrobić [d-dodaj, w-wypisz]")

if action == 'd':
    name = input("Podaj imię: ")
    last_name = input("Podaj nazwisko: ")
    b_year = input("Rok urodzenia: ")
    salary = input("Pensja: ")

    employee = {
        "name": name,
        "last_name": last_name,
        "b_year": b_year,
        "salary": salary
    }
    employes.append(employee)
    with open("pracownicy.json", "w") as fp:
        json.dump(employes, fp)

elif action == "w":
    for i, e in enumerate(employes, start=1):
        print(f"- [{i}] {e['name']} {e['last_name']} - rok: {e['b_year']}, pensja: {e['salary']}")
