import re

with open("input.txt") as f:
    dane = f.read()

pattern_zip_code = re.compile("\d{2}-\d{3}")
print(pattern_zip_code.findall(dane))

pattern_email = re.compile("[\w._\-]+@[\w._\-]+")
print(pattern_email.findall(dane))

pattern_dates = re.compile("\d{2} \w{3} \d{4}")
print(pattern_dates.findall(dane))
