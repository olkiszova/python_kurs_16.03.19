import tkinter
import requests

from zadanie_2 import get_location_id, get_location_weather

def pogoda():
    localization_name = localization.get()
    location_id = get_location_id(localization_name)
    weather = get_location_weather(location_id)
    description = f"""
    Pogoda w {localization_name}:
    temperatura: {weather['the_temp']}    
    ciśnienie: {weather['air_pressure']}
    wilgotność: {weather['humidity']}
        """
    pogoda_label.configure(text=description)

root = tkinter.Tk()
localization = tkinter.Entry(master=root)
localization.pack()
button = tkinter.Button(master=root, text="Pobierz pogodę", command=pogoda)
button.pack()

pogoda_label = tkinter.Label(master=root, text="-")
pogoda_label.pack()

root.mainloop()