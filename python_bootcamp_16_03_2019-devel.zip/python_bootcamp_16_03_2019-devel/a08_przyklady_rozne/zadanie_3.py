import tkinter

def oblicz():
    dystans = float(entry_dystans.get())
    spalanie = float(entry_spalanie.get())
    cena = float(entry_cena.get())
    koszt = (dystans/100) * spalanie * cena
    label_wynik.configure(text=f"koszt: {koszt}")

root = tkinter.Tk()

label_dystans = tkinter.Label(master=root, text="dystans")
label_dystans.grid(row=0, column=0)
entry_dystans = tkinter.Entry(master=root)
entry_dystans.grid(row=0, column=1)

label_spalanie = tkinter.Label(master=root, text="spalanie")
label_spalanie.grid(row=1, column=0)
entry_spalanie = tkinter.Entry(master=root)
entry_spalanie.grid(row=1, column=1)

label_cena = tkinter.Label(master=root, text="cena")
label_cena.grid(row=2, column=0)
entry_cena = tkinter.Entry(master=root)
entry_cena.grid(row=2, column=1)

oblicz = tkinter.Button(master=root, text="Oblicz", command=oblicz)
oblicz.grid(row=3, column=0)

label_wynik = tkinter.Label(master=root, text="-")
label_wynik.grid(row=4, column=0)

root.title("Spalanie")
root.mainloop()