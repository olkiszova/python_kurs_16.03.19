liczby = [5, 2, 1, 4, 3]   # [1, 2, 5, 4, 3]
        #[0, 1, 2, 3, 4]
temp_max = liczby[0]
temp_min = liczby[0]
# symulujemy działanie max i min  - tu są zapisywane wartości
for el in liczby:
    if el > temp_max:
        temp_max = el
    if el < temp_min:
        temp_min = el

# index_min, index_max = 0, 0
#
# for index in range(len(liczby)):
#     if liczby[index] < liczby[index_min]:
#         index_min = index
#     if liczby[index] > liczby[index_max]:
#         index_max = index
#
# liczby[index_min], liczby[index_max] = liczby[index_max], liczby[index_min]

# teraz chcemy miec indeksy - ale bez uzycia metody index
for el in range(len(liczby)):
    if liczby[el] > temp_max:
        temp_max = liczby[el]
        temp_max_i = el
    if liczby[el] < temp_min:
        temp_min = liczby[el]
        temp_min_i = el

# enumerate

for i, v in enumerate(liczby):
    print(i, v)

#
# # Tu będziemy modyfikować liczby
#
i_max = liczby.index(max(liczby))
i_min = liczby.index(min(liczby))
liczby[i_min], liczby[i_max] = liczby[i_max], liczby[i_min]

# sposob Dominiki:
a = min(liczby)
b = max(liczby)
poz_a = liczby.index(a)
poz_b = liczby.index(b)
liczby.remove(a)
liczby.insert(poz_a, b)
liczby.remove(b)
liczby.insert(poz_b, a)


print(liczby)

assert liczby == [1, 2, 5, 4, 3]