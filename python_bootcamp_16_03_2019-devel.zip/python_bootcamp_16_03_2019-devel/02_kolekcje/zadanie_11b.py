dane = input("Podaj liczby rozdzielajac je przecinkien")
unikalne_liczby = {int(el) for el in dane.split(",")}

print(f"Unikalnych liczb: {len(unikalne_liczby)}")
print(f"Z czego parzystych w przedziale 0-100 jest "
      f"+{len(unikalne_liczby & set(range(0, 101, 2)))}")

