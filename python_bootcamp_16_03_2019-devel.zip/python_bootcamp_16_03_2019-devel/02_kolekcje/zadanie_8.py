napis = "Ala ma <kota>, a kot ma Ale"

licznik = 0
czy_zliczac = False

for znak in napis:
    if znak == "<":
        czy_zliczac = True
    elif znak == ">":
        czy_zliczac = False
    elif czy_zliczac:
        licznik += 1

print(licznik)