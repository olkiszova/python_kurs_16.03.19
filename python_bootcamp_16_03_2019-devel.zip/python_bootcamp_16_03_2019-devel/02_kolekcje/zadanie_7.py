napis = input("Podaj napis: ")

# SAMOGLOSKI = ('a', 'e', 'i', 'o', 'u', 'y')
SAMOGLOSKI = "aeiouy"
licznik = 0

for litera in napis.lower():
    if litera in SAMOGLOSKI:
        licznik += 1

print(f"W tekście: '{napis}' znajduje się {licznik} samogłosek")