x = []
while len(x) < 10:
    x.append(int(input("Podaj liczbe: ")))
print(sum(x)/len(x))


