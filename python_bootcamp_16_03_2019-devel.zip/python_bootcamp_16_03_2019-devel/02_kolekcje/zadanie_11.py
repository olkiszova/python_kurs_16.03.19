unikalne_liczby = set()

while True:
    dana = input("Podaj liczbę")
    if dana == "k":
        break
    unikalne_liczby.add(int(dana))

print(f"Unikalnych liczb: {len(unikalne_liczby)}")
print(f"Z czego parzystych w przedziale 0-100 jest {len(unikalne_liczby & set(range(0, 101, 2)))}")



