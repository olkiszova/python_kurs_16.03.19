x = (2, 3, 4, 12, 34, 55, 67, 45, 67, 13)

# drugi element
print(x[1])
# I przedostatni element
print(x[-2])
# I elementy od trzeciego do siódmego (włacznie)
print(x[2:7])
# I co trzeci element
print(x[::3])
# I co drugi element liczac od konca
print(x[-2::-2])