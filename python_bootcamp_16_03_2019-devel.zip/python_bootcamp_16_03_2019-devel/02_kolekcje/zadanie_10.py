tekst = input("Wpisz tekst: ")
liczniki = {}

for znak in tekst:
    liczniki[znak] = liczniki.get(znak, 0) + 1
print(liczniki)

# if znak in liczniki:
#     liczniki[znak] += 1
# else:
#     liczniki[znak] = 1