x = [1, 10, 20, 30, 40, 50, 60]

i = 0
while i < len(x):
    print(x[i])
    i += 1

for a in x:
    print(a)

for i, a in enumerate(x, start=100):
    print(i, a)

for a in x:
    if a == 20:
        continue
    print(a)

for a in x:
    if a == 40:
        break
    print(a)



print("ABC", end="")
print("ABC")
x = 5
print(f"{x:5}", end="")
print()
print(f"{x:5}", end="")