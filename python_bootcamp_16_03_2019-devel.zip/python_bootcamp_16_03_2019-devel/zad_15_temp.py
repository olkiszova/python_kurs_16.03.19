i = 0
while True:
    print("cos tam")
    i += 1
    if i == 5:
        break
else:
    print("Jestem w else")


print("jestem po pętli")

print("-"*30)
i = 0
while i < 6:
    print("cos tam")
    i += 1
else:
    print("Jestem w Else")


print("jestem po pętli")