import math

10 ** 10

# Działania na liczbach
print("Działania na liczbach")
print("Argumenty całkowite")
print(10 + 10)  # to też jest komentarz
print(10 - 10)
print(10 * 10)
print(10 / 3)
print(10 // 3)
print(10 % 3)
print(10 ** 2)
print(math.sqrt(10))
print()

print("Argumenty zmiennoprzecinkowe")
print(10.0 + 10.0)
print(10.0 - 10.0)
print(10.0 * 10.0)
print(10.0 / 3.0)
print(10.0 // 3.0)
print(10.0 % 3.0)
print(10.0 ** (0.5))
print(math.sqrt(10.0))
print()

print("Argumenty mieszane")
print(10 + 10.0)
print(10 - 10.0)
print(10 * 10.0)
print(10 / 3.0)
print(10 // 3.0)
print(10 % 3.0)
print(10 ** (0.5))

print(((10 + 3) * 17) / (20 ** 3))
print(10 + 3 * 17 / 20 ** 3)
