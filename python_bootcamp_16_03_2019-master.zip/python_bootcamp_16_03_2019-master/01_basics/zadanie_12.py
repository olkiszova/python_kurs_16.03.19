# Tu będzie rozwiązanie zadanie 12

x =1 