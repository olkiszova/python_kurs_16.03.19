import datetime
today = datetime.datetime.now()
aktualny_rok = today.year

rok_ur = int(input("Podaj rok urodzenia: "))

if (aktualny_rok - rok_ur) > 18:
    print("Jesteś pełnoletni")
else:
    print("Musisz jeszcze poczekać")
