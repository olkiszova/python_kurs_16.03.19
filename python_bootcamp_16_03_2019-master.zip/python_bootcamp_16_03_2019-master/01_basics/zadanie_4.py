cena_za_kg = input("Cena za kg: ")
waga = input("Waga: ")

naleznosc = float(cena_za_kg) * float(waga)

print("Należność:", naleznosc)
print("Należność: " + str(naleznosc))
print(f"Należność: {naleznosc}")

print(f"Należność: {naleznosc}, wyliczone na podstawie zmiennych: cena={cena_za_kg}, waga={waga} aaaa \n"
      f"aaa aaa aaa aaa aaa aaa ")


print(f"""Należność: {naleznosc}, wyliczone na podstawie zmiennych: cena={cena_za_kg}, waga={waga} aaaa 
aaa aaa aaa aaa aaa aaa """)
