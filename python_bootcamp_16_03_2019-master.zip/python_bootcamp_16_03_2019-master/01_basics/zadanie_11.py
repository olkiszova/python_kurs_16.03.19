x = int(input("Podaj pozycje gracza X: "))
y = int(input("Podaj pozycje gracza Y: "))

if x < 0 or x > 100 or y < 0 or y > 100:
    print("Jesteś poza planszą")
elif x >= 90 and y >= 90:
    print("Jesteś w GPR")
elif x >= 90 and y <= 10:
    print("Jesteś w DPR")
elif x <= 10 and y >= 90:
    print("Jesteś w GLR")
elif x <= 10 and y <= 10:
    print("Jesteś w DLR")
elif x >= 90:
    print("Jesteś na PK")
elif x <= 10:
    print("Jesteś na LK")
elif y >= 90:
    print("Jesteś na GK")
elif y <= 10:
    print("Jesteś na DK")
else:
    print("Centrum!!")

# ver 2

if x < 0 or x > 100 or y < 0 or y > 100:
    print("Jesteś poza planszą")
elif 10 < x < 90 and 10 < y < 90:
    print("Jesteś w centrum")
elif x >= 90:
    if y >= 90:
        print("jesteś w GPR")
    elif y <= 10:
        print("jesteś w DPR")
    else:
        print("Jesteś na prawej krawędzi")
elif x <= 90:
    if y >= 90:
        print("jesteś w GLR")
    elif y <= 10:
        print("jesteś w DLR")
    else:
        print("Jesteś na lewej krawędzi")
elif y >= 90:
    print("jesteś na GK")
elif y <= 10:
    print("jesteś na DK")
else:
    print ("Nie wiem gdzie jestem ")