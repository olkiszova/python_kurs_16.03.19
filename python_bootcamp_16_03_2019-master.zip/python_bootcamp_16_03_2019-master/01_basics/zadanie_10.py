a = int(input("Podaj pierwszą liczbę: "))
b = int(input("Podaj drugą liczbę: "))
operacja = input("Określ operację [+-/* ** %]")

if operacja == "+":
    wynik = a + b
elif operacja == "-":
    wynik = a - b
elif operacja == "/":
    if b == 0:
        wynik = "Nie dziel przez zero cholero!"
    else:
        wynik = a / b
elif operacja == "*":
    wynik = a * b
elif operacja == "**":
    wynik = a ** b
elif operacja == "%":
    wynik = a % b

print(f"Wynik={wynik}")