# ctr + alt + L
imie = input("Podaj imie: ")
wzrost = input("Podaj wzrost [ m ]: ")
waga = input("Podaj wagę: ")

bmi = int(waga) / (float(wzrost) ** 2)

print("Imie: " + imie)
print("Wzrost: " + wzrost)
print("BMI: " + str(bmi))
