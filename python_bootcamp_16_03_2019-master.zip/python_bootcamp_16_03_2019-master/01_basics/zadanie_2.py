"""
a=3
b=9
h=6.5

_=10
print("a", a)
print(((a+b)*h)/2)


a=10
b=20
h=10.5

_=10
print("a", a)
print(((a+b)*h)/2)
"""
