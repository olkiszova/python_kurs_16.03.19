wymiary = input("Podaj wymiary rozdzielajac je przecinkiem: ")
a, b, c = wymiary.split(",")
a, b, c = int(a), int(b), int(c)

objetosc = a * b * c

# print("Czy objętość większa od 1 l? ", objetosc > 1000)
# input()

# if () {
# cos tam
# } else
# { cos tam innego}

if objetosc < 1000: # jesli True to kolejna linia zostanie wykonana
    print("Objętość jest mniejsza niż 1 litr")
elif objetosc == 1000:
    print("To jest 1 litr")
else:
    print("Objętość jest większa niż 1 litr")

x = 3

if x==1:
    print("Sukces")
elif x==2:
    print("Drugi sukces")
else:
    print("Wpadłem do else")

print("To jest miejsce do sprzątania")